package com.sparkProject

import org.apache.spark.sql.{SQLContext, SparkSession}
import org.apache.spark.ml.feature.VectorAssembler
import org.apache.spark.ml.feature.StandardScaler
import org.apache.spark.ml.feature.{OneHotEncoder, StringIndexer}
import org.apache.spark.ml.classification.LogisticRegression
import org.apache.spark.ml.evaluation.RegressionEvaluator
import org.apache.spark.ml.regression.LinearRegression
import org.apache.spark.ml.tuning.{ParamGridBuilder, TrainValidationSplit}
import org.apache.spark.ml.evaluation.{BinaryClassificationEvaluator, RegressionEvaluator}
import org.apache.spark.ml.tuning.{CrossValidator, ParamGridBuilder}
/**
  * Created by stephanetrublereau on 25/10/2016.
  */
object JobML {
  def main(args: Array[String]): Unit = {
    // SparkSession configuration
    val spark = SparkSession
      .builder
      .master("local")
      .appName("spark session TP_parisTech")
      .getOrCreate()

    val sc = spark.sparkContext

    import spark.implicits._
    /** ******************************************************************************
      *
      * TP 4 : previsions avec modele LogisticRegression() sur donnees
      *
      * *******************************************************************************/
    val df_cumulative = spark
      .read
      .parquet("/Users/stephanetrublereau/documents/tp_spark/cleanedDataFrame.parquet")
    /** ******************************************************************************
      *
      *  Verification des donnees en entrée et péparations pour rentrée dans le modèle
      *  LogisticRegression
      *
      * *******************************************************************************/
    println("nombre de ligne : ", df_cumulative.count())
    println("nombre de colonnes : ", df_cumulative.columns.length)

    /** *****************************************************************************
      *   -  Elimination des colonnes du dataframe  : row_id  et koi_disposition)     *
      * *******************************************************************************/
    val colonnes = df_cumulative.columns.filter(col => col != "koi_disposition" && col != "rowid")
    /*       * Vérification de la liste des colonnes                                   */
    colonnes.foreach(x => println(x))
    /*       * Affichage du schme de la dataframe                                      */
    df_cumulative.printSchema

    /*********************************************************************************/
    /*    -  Création d'un vecteur features  reunissant toutes les colonnes          *
     *       (entrant du modèle)                                                     *
     *                 * Structure du vecteurs liste des colonnes : colonnes         *
     *                   et nom du vecteurs                                          *
     *                 * Alimentation du vecteurs a partir de la dataframe           *
     *                 * Vérification du nombre de ligne et de colonne du vecteur    *
     *********************************************************************************/
    val assembler = new VectorAssembler()
      .setInputCols(colonnes)
      .setOutputCol("features")

    val vecteurs = assembler.transform(df_cumulative)
    //
    println("nombre de ligne : ", vecteurs.count())
    println("nombre de colonnes : ", vecteurs.columns.length)
    //vecteurs.printSchema()

    /*********************************************************************************/
    /*     -  Creation d'une dataframe avec deux colonnes                            *
     *                                  koi_disposition et features                  *
     *********************************************************************************/
    val df_proc = vecteurs.select("koi_disposition", "features")
    println("nombre de ligne : ", df_proc.count())
    println("nombre de colonnes : ", df_proc.columns.length)
    df_proc.printSchema
    df_proc.show()

    /*********************************************************************************/
    /*     -  Creation d'une colonne de 0 et de 1,                                   *
     *        necessaire pour une classification binaire(LogisticRegression)         *
     *        à parir de koi_disposition --> création colonne label                  *
     *               * Structure                                                     *
     *               * Alimentation à partir de la dataframe df_pr                   *
     *               * Vérification de l'index asembler créer                        *
     *********************************************************************************/
    val indexer = new StringIndexer()
      .setInputCol("koi_disposition")
      .setOutputCol("label")
      .fit(df_proc)
    val indexed = indexer.transform(df_proc)
    indexed.printSchema
    indexed.show()

    /*********************************************************************************/
    /*     -  Preparation à partir des données fournies de deux lots                 *
     *        un pour l'entrainement du modèle l'autre pour tester le modèle         *
     *********************************************************************************/
    val Array(trainningData, testData) = indexed.randomSplit(Array(0.9, 0.1))
    trainningData.printSchema()
    trainningData.show()

    /*********************************************************************************/
    /*     -  Parmetrage du modèle LogisticRegression                                *
     *********************************************************************************/
    val lr = new LogisticRegression()
      .setElasticNetParam(1.0)  // L1-norm regularisation : LASSO
      .setLabelCol("label")
      .setFeaturesCol("features")
      .setStandardization(true)  // we already scaled the data
      .setFitIntercept(true)  // we want an affine regression (with false, it is a linear regression)
      .setTol(1.0e-4)  // stop criterion of the algorithm based on its convergence
      .setMaxIter(500)  // a security stop criterion to avoid infinite loops si pas de convergence

    /*********************************************************************************/
    /*     -  Fabrication d'un Array increment de 10e-6 à 1 par log(0.5)             *
     *********************************************************************************/
    val regparam =  (-6.0 to 0.0 by 0.5 toArray).map(math.pow(10,_))
    // (0.000001,0.000005, 0.00001, 0.00005, 0.0001, 0.0005, 0.001, 0.005, 0.01, 0.05, 0.1, 0.5, 1.0)
    print(regparam)
    /*********************************************************************************/
    /*     -  Fabrication du parametre grid(grille) nécessaire à la cross validation  *
     *********************************************************************************/
    val paramGrid = new ParamGridBuilder()
      .addGrid(lr.regParam, regparam)//
      // .addGrid(lr.fitIntercept)
    //  .addGrid(lr.elasticNetParam, Array(0.0, 0.5, 1.0))
      .build()
    /*********************************************************************************/
    /*     -  Cross validation du modele lr                                          *
     *********************************************************************************/
    val cv = new CrossValidator()
      .setEstimator(lr)
      .setEvaluator(new BinaryClassificationEvaluator)
      .setEstimatorParamMaps(paramGrid)
      .setNumFolds(2)  // Use 3+ in practice
    // Run cross-validation, and choose the best set of parameters.
    val cvModel = cv.fit(trainningData)

    /*********************************************************************************/
    // Make predictions datatest sur le model
    // model is the model with combination of parameters that performed best.
    //
    // il a été nécessaire de séparé la creation de la prediction de la selection
    // de des colonne pour affichage
    /*********************************************************************************/
    val predictions = cvModel.transform(testData)
    predictions.select("features", "label", "prediction").show()

    /*********************************************************************************/
    // calcul la probailité d'erreur
    /*********************************************************************************/
    val evaluator = new BinaryClassificationEvaluator()
      .setLabelCol("label")
      .setRawPredictionCol("prediction")
      .setMetricName("areaUnderROC")

    val ROC = evaluator.evaluate(predictions)
    println("ROC BinaryClassificationEvaluator : " + ROC)

    /**********************************************************************************/
    // Sauvegarde du modele entraine pour pouvoir l'utiliser plus tard
    /**********************************************************************************/
    val modeloutputpath ="/Users/stephanetrublereau/documents/tp_spark/model/"
    cvModel.write.overwrite().save(modeloutputpath)
  }
}